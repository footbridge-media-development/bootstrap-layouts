# Footbridge Media's Bootstrap Layouts

Our translation cheatsheet is located at this repository's home page here: [Flex-Bootstrap Cheatsheet](https://footbridgemediapensacola.github.io/bootstrap-layouts/)