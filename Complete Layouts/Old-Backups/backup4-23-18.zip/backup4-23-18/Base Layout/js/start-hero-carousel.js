$(document).ready(function(){
	$('#heroCarousel').carousel({
		interval: 5000
	})
});